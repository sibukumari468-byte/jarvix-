package com.example.jarvix

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null

    private val apps = mapOf(
        "youtube" to "com.google.android.youtube",
        "whatsapp" to "com.whatsapp",
        "gmail" to "com.google.android.gm",
        "maps" to "com.google.android.apps.maps",
        "instagram" to "com.instagram.android",
        "spotify" to "com.spotify.music",
        "chrome" to "com.android.chrome",
        "camera" to "com.android.camera"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        status = TextView(this).apply {
            textSize = 20f
            gravity = Gravity.CENTER
            text = "Tap the button and speak"
        }
        val btn = Button(this).apply {
            text = "Speak to Jarvix"
            textSize = 20f
            setOnClickListener { listen() }
        }
        layout.addView(status)
        layout.addView(btn)
        setContentView(layout)
        tts = TextToSpeech(this, this)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        }
    }

    override fun onInit(s: Int) {
        if (s == TextToSpeech.SUCCESS) tts?.language = Locale("en", "IN")
    }

    private fun say(t: String) {
        status.text = t
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "jarvix")
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Speech recognition is not available")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle?) {
                val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t != null) handle(t)
            }
            override fun onError(e: Int) { say("I did not hear you. Try again.") }
            override fun onReadyForSpeech(p: Bundle?) { status.text = "Listening..." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
        recognizer?.startListening(i)
    }

    private fun openUrl(url: String) {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun handle(raw: String) {
        val t = raw.lowercase(Locale.ROOT).replace("jarvix", "").replace("jarvis", "").trim()
        when {
            t.startsWith("play ") -> {
                val q = t.removePrefix("play ").removeSuffix(" songs").removeSuffix(" song").trim()
                say("Playing $q")
                openUrl("https://www.youtube.com/results?search_query=" + Uri.encode("$q song"))
            }
            t.startsWith("open ") -> {
                val n = t.removePrefix("open ").trim()
                val launch = apps[n]?.let { packageManager.getLaunchIntentForPackage(it) }
                if (launch != null) {
                    say("Opening $n")
                    startActivity(launch)
                } else {
                    say("Searching for $n")
                    openUrl("https://www.google.com/search?q=" + Uri.encode(n))
                }
            }
            t.startsWith("search ") -> {
                val q = t.removePrefix("search ").trim()
                say("Searching for $q")
                openUrl("https://www.google.com/search?q=" + Uri.encode(q))
            }
            else -> {
                say("Searching for $t")
                openUrl("https://www.google.com/search?q=" + Uri.encode(t))
            }
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
